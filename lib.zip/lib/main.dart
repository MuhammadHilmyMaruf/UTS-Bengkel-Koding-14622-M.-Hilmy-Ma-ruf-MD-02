import 'package:flutter/material.dart';
import 'todo_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Todo List Film',
      theme: ThemeData(primarySwatch: Colors.deepPurple),
      home: TodoPage(),
    );
  }
}
