import 'package:flutter/material.dart';
import 'todo.dart';
import 'database_helper.dart';

class TodoPage extends StatefulWidget {
  const TodoPage({super.key});

  @override
  _TodoPageState createState() => _TodoPageState();
}

class _TodoPageState extends State<TodoPage> {
  List<Todo> _todos = [];
  String _searchQuery = '';
  final _dbHelper = DatabaseHelper();

  @override
  void initState() {
    super.initState();
    _refreshTodos();
  }

  void _refreshTodos() async {
    final data = await _dbHelper.getTodos();
    setState(() {
      _todos = data;
    });
  }

  void _showForm({Todo? todo}) {
    final titleController = TextEditingController(text: todo?.title);
    final descriptionController = TextEditingController(
      text: todo?.description,
    );

    showDialog(
      context: context,
      builder:
          (_) => AlertDialog(
        title: Text(todo == null ? 'Tambah Film' : 'Update Film'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: titleController,
              decoration: InputDecoration(labelText: 'Judul Film'),
            ),
            TextField(
              controller: descriptionController,
              decoration: InputDecoration(labelText: 'Deskripsi'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (todo == null) {
                await _dbHelper.insertTodo(
                  Todo(
                    title: titleController.text,
                    description: descriptionController.text,
                  ),
                );
              } else {
                await _dbHelper.updateTodo(
                  Todo(
                    id: todo.id,
                    title: titleController.text,
                    description: descriptionController.text,
                    isDone: todo.isDone,
                  ),
                );
              }
              Navigator.of(context).pop();
              _refreshTodos();
            },
            child: Text(todo == null ? 'Tambah' : 'Update'),
          ),
        ],
      ),
    );
  }

  void _confirmDelete(int id) {
    showDialog(
      context: context,
      builder:
          (_) => AlertDialog(
        title: Text('Hapus Film?'),
        content: Text('Yakin ingin menghapus film ini?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () async {
              await _dbHelper.deleteTodo(id);
              Navigator.of(context).pop();
              _refreshTodos();
            },
            child: Text('Hapus'),
          ),
        ],
      ),
    );
  }

  void _confirmDeleteCompleted() {
    showDialog(
      context: context,
      builder:
          (_) => AlertDialog(
        title: Text('Hapus Semua Film Selesai?'),
        content: Text(
          'Yakin ingin menghapus semua film yang sudah ditonton?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () async {
              await _dbHelper.deleteCompletedTodos();
              Navigator.of(context).pop();
              _refreshTodos();
            },
            child: Text('Hapus Semua'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filteredTodos =
    _todos.where((todo) {
      return todo.title.toLowerCase().contains(_searchQuery.toLowerCase());
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text('Todo List Film'),
        actions: [
          IconButton(
            icon: Icon(Icons.delete_forever),
            onPressed: _confirmDeleteCompleted,
          ),
        ],
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(kToolbarHeight),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Cari Film...',
                filled: true,
                fillColor: Colors.white,
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                });
              },
            ),
          ),
        ),
      ),
      body: ListView.builder(
        itemCount: filteredTodos.length,
        itemBuilder: (context, index) {
          final todo = filteredTodos[index];
          return ListTile(
            leading: Checkbox(
              value: todo.isDone,
              onChanged: (value) async {
                await _dbHelper.updateTodo(
                  Todo(
                    id: todo.id,
                    title: todo.title,
                    description: todo.description,
                    isDone: value ?? false,
                  ),
                );
                _refreshTodos();
              },
            ),
            title: Text(
              todo.title,
              style: TextStyle(
                decoration: todo.isDone ? TextDecoration.lineThrough : null,
              ),
            ),
            subtitle: Text(todo.description),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Icon(Icons.edit, color: Colors.orange),
                  onPressed: () => _showForm(todo: todo),
                ),
                IconButton(
                  icon: Icon(Icons.delete, color: Colors.red),
                  onPressed: () => _confirmDelete(todo.id!),
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showForm(),
        child: Icon(Icons.add),
      ),
    );
  }
}
